#include <iostream>         
#include <cstdlib>          
#include <GL/glew.h>        
#include <GLFW/glfw3.h>     
#define STB_IMAGE_IMPLEMENTATION
#include <stb_image.h> 

#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <camera.h>


using namespace std;


#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

namespace {
    const char* const WINDOW_TITLE = "Project";


    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;


    struct GLMesh {
        GLuint vao;
        GLuint vbos[2];
        GLuint nIndices;
    };

    struct GLMesh2 {
        GLuint vao;
        GLuint vbos[2];
        GLuint nIndices;
    };
    struct GLMesh3 {
        GLuint vao;
        GLuint vbos[2];
        GLuint nIndices;
    };
    struct GLMesh4 {
        GLuint vao;
        GLuint vbos[2];
        GLuint nIndices;
    };
    struct GLMesh5 {
        GLuint vao;
        GLuint vbos[2];
        GLuint nIndices;
    };


    GLFWwindow* gWindow = nullptr;

    GLMesh gMesh;
    GLMesh2 gMesh2;
    GLMesh3 gMesh3;
    GLMesh4 gMesh4;
    GLMesh5 gMesh5;

    GLuint gTextureIdDeskTop;
    glm::vec2 gUVScale(5.0f, 5.0f);

    GLuint gTextureIdMousePad;
    glm::vec2 gUVScale2(5.0f, 5.0f);

    GLuint gTextureIdPlastic;
    glm::vec2 gUVScale3(5.0f, 5.0f);




    GLuint gProgramId;
    GLuint gLightProgramId;


    Camera gCamera(glm::vec3(0.0f, 2.0f, 7.0f));
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;


    float gDeltaTime = 0.0f;
    float gLastFrame = 0.0f;

    glm::vec3 gObjectPosition(0.0f, 0.0f, 0.0f);
    glm::vec3 gObjectScale(2.0f);

    glm::vec3 gObjectColor(0.0f, 0.0f, 0.0f);
    glm::vec3 gLightColor(1.0f, 1.0f, 1.0f);

    glm::vec3 gLightPosition(1.0f, 2.0f, -1.0f);
    glm::vec3 gLightScale(4.0f);
}


bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void UCreateMesh(GLMesh& mesh);
void UCreateMesh2(GLMesh2& mesh2);
void UCreateMesh3(GLMesh3& mesh3);
void UCreateMesh4(GLMesh4& mesh4);
void UCreateMesh5(GLMesh5& mesh5);
void UDestroyMesh(GLMesh& mesh);
void UDestroyMesh2(GLMesh2& mesh2);
void UDestroyMesh3(GLMesh3& mesh3);
void UDestroyMesh4(GLMesh4& mesh4);
void UDestroyMesh5(GLMesh5& mesh5);
bool UCreateTexture(const char* filename, GLuint& textureId);
void UDestroyTexture(GLuint textureId);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);


const GLchar* vertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position;
layout(location = 1) in vec3 normal;
layout(location = 2) in vec2 textureCoordinate;

out vec3 vertexNormal;
out vec3 vertexFragmentPos;
out vec2 vertexTextureCoordinate;



uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main() {

    gl_Position = projection * view * model * vec4(position, 1.0f);

    vertexFragmentPos = vec3(model * vec4(position, 1.0f));

    vertexNormal = mat3(transpose(inverse(model))) * normal;
    vertexTextureCoordinate = textureCoordinate;
}
);



const GLchar* fragmentShaderSource = GLSL(440,

    in vec2 vertexTextureCoordinate;
in vec3 vertexNormal;
in vec3 vertexFragmentPos;

out vec4 fragmentColor;
out vec4 fragmentColor2;
out vec4 fragmentColor3;

uniform vec3 objectColor;
uniform vec3 lightColor;
uniform vec3 lightPos;
uniform vec3 viewPosition;
uniform sampler2D uTexture;
uniform sampler2D uTextureMousePad;
uniform sampler2D uTexturePlastic;
uniform vec2 uvScale;



void main() {

    float ambientStrength = 0.5f;
    vec3 ambient = ambientStrength * lightColor;

    vec3 norm = normalize(vertexNormal);
    vec3 lightDirection = normalize(lightPos - vertexFragmentPos);
    float impact = max(dot(norm, lightDirection), 0.0);
    vec3 diffuse = impact * lightColor;

    float specularIntensity = 1.0f;
    float highlightSize = 1.0f;
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos);
    vec3 reflectDir = reflect(-lightDirection, norm);

    float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    vec3 specular = specularIntensity * specularComponent * lightColor;

    vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);
    vec4 textureColor2 = texture(uTextureMousePad, vertexTextureCoordinate * uvScale);
    vec4 textureColor3 = texture(uTexturePlastic, vertexTextureCoordinate * uvScale);

    vec3 lightResults = (ambient + diffuse + specular);


    vec3 phong = (lightResults) * textureColor.xyz;
    vec3 phong2 = (lightResults) * textureColor2.xyz;
    vec3 phong3 = (lightResults) * textureColor3.xyz;

    fragmentColor = vec4(phong, 1.0);
    fragmentColor2 = vec4(phong2, 1.0);
    fragmentColor3 = vec4(phong3, 1.0);

});

const GLchar* lightVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position;


uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f);
}
);



const GLchar* lightFragmentShaderSource = GLSL(440,
out vec4 fragmentColor; 
out vec4 fragmentColor2;
out vec4 fragmentColor3;

void main()
{
    fragmentColor = vec4(1.0f); 
    fragmentColor2 = vec4(1.0f);
    fragmentColor3 = vec4(1.0f);
}
);


void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}


int main(int argc, char* argv[]) {

    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;


    UCreateMesh(gMesh);
    UCreateMesh2(gMesh2);
    UCreateMesh3(gMesh3);
    UCreateMesh4(gMesh4);
    UCreateMesh5(gMesh5);


    if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId)) {
        return EXIT_FAILURE;
    }

    const char* texFilename = "DeskTop.jpg";
    if (!UCreateTexture(texFilename, gTextureIdDeskTop))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "mousePad.jpg";
    if (!UCreateTexture(texFilename, gTextureIdMousePad))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "Plastic.jfif";
    if (!UCreateTexture(texFilename, gTextureIdPlastic))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }


    glUseProgram(gProgramId);

    glUniform1i(glGetUniformLocation(gProgramId, "uTextureDeskTop"), 0);
    glUniform1i(glGetUniformLocation(gProgramId, "uTextureMousePad"), 1);
    glUniform1i(glGetUniformLocation(gProgramId, "uTexturePlastic"), 2);



    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    //wireframe option
    //glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);


    while (!glfwWindowShouldClose(gWindow)) {

        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;

        UProcessInput(gWindow);


        URender();

        glfwPollEvents();
    }


    UDestroyMesh(gMesh);
    UDestroyMesh2(gMesh2);
    UDestroyMesh3(gMesh3);
    UDestroyMesh4(gMesh4);
    UDestroyMesh5(gMesh5);

    UDestroyTexture(gTextureIdDeskTop);
    UDestroyTexture(gTextureIdMousePad);
    UDestroyTexture(gTextureIdPlastic);

    UDestroyShaderProgram(gLightProgramId);

    UDestroyShaderProgram(gProgramId);

    exit(EXIT_SUCCESS);
}



bool UInitialize(int argc, char* argv[], GLFWwindow** window) {

    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif


    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL) {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult) {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }


    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}



void UProcessInput(GLFWwindow* window) {
    static float cameraSpeed = 2.5f;

    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        gCamera.ProcessKeyboard(UP, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        gCamera.ProcessKeyboard(DOWN, gDeltaTime);
}



void UResizeWindow(GLFWwindow* window, int width, int height) {
    glViewport(0, 0, width, height);
}


void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos;

    gLastX = xpos;
    gLastY = ypos;

    gCamera.ProcessMouseMovement(xoffset, yoffset);
}



void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    gCamera.ProcessMouseScroll(yoffset);
}


void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    switch (button)
    {
    case GLFW_MOUSE_BUTTON_LEFT:
    {
        if (action == GLFW_PRESS)
            cout << "Left mouse button pressed" << endl;
        else
            cout << "Left mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_MIDDLE:
    {
        if (action == GLFW_PRESS)
            cout << "Middle mouse button pressed" << endl;
        else
            cout << "Middle mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_RIGHT:
    {
        if (action == GLFW_PRESS)
            cout << "Right mouse button pressed" << endl;
        else
            cout << "Right mouse button released" << endl;
    }
    break;

    default:
        cout << "Unhandled mouse button event" << endl;
        break;
    }
}



void URender() {

    glEnable(GL_DEPTH_TEST);


    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glBindVertexArray(gMesh.vao);


    glUseProgram(gProgramId);

    glm::mat4 rotation = glm::rotate(60.0f, glm::vec3(0.0f, 1.0f, 0.0f));


    glm::mat4 model = glm::translate(gObjectPosition) * glm::scale(gObjectScale) * rotation;



    glm::mat4 view = gCamera.GetViewMatrix();


    glm::mat4 projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);




    GLint modelLoc = glGetUniformLocation(gProgramId, "model");
    GLint viewLoc = glGetUniformLocation(gProgramId, "view");
    GLint projLoc = glGetUniformLocation(gProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    GLint objectColorLoc = glGetUniformLocation(gProgramId, "objectColor");
    GLint lightColorLoc = glGetUniformLocation(gProgramId, "lightColor");
    GLint lightPositionLoc = glGetUniformLocation(gProgramId, "lightPos");
    GLint viewPositionLoc = glGetUniformLocation(gProgramId, "viewPosition");

    glUniform3f(objectColorLoc, gObjectColor.r, gObjectColor.g, gObjectColor.b);
    glUniform3f(lightColorLoc, gLightColor.r, gLightColor.g, gLightColor.b);
    glUniform3f(lightPositionLoc, gLightPosition.x, gLightPosition.y, gLightPosition.z);
    const glm::vec3 cameraPosition = gCamera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

    GLint UVScaleLoc = glGetUniformLocation(gProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));
    GLint UVScaleLoc2 = glGetUniformLocation(gProgramId, "uvScale2");
    glUniform2fv(UVScaleLoc2, 1, glm::value_ptr(gUVScale2));
    GLint UVScaleLoc3 = glGetUniformLocation(gProgramId, "uvScale3");
    glUniform2fv(UVScaleLoc3, 1, glm::value_ptr(gUVScale3));

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureIdDeskTop);

    glDrawElements(GL_TRIANGLES, gMesh.nIndices, GL_UNSIGNED_SHORT, NULL);

    glBindVertexArray(gMesh2.vao);


    glUseProgram(gProgramId);

    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, gTextureIdMousePad);

    glDrawElements(GL_TRIANGLES, gMesh2.nIndices, GL_UNSIGNED_SHORT, NULL);

    glBindVertexArray(gMesh3.vao);


    glUseProgram(gProgramId);

    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D, gTextureIdPlastic);

    glDrawElements(GL_TRIANGLES, gMesh3.nIndices, GL_UNSIGNED_SHORT, NULL);

    glBindVertexArray(gMesh4.vao);


    glUseProgram(gProgramId);

    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D, gTextureIdPlastic);

    glDrawElements(GL_TRIANGLES, gMesh4.nIndices, GL_UNSIGNED_SHORT, NULL);

    glBindVertexArray(gMesh5.vao);


    glUseProgram(gProgramId);

    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D, gTextureIdPlastic);

    glDrawElements(GL_TRIANGLES, gMesh5.nIndices, GL_UNSIGNED_SHORT, NULL);

    glUseProgram(gLightProgramId);


    model = glm::translate(gLightPosition) * glm::scale(gLightScale);


    modelLoc = glGetUniformLocation(gLightProgramId, "model");
    viewLoc = glGetUniformLocation(gLightProgramId, "view");
    projLoc = glGetUniformLocation(gLightProgramId, "projection");


    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));






    glBindVertexArray(0);
    glUseProgram(0);


    glfwSwapBuffers(gWindow);
}



void UCreateMesh(GLMesh& mesh) {

    GLfloat verts[] = {

        1.0f, 0.0f, 0.5f,  1.0f, 1.0f, 1.0f,  1.0f, 1.0f,
        1.0f, 0.0f, -0.5f,  1.0f, 1.0f, 1.0f,  1.0f, 0.0f,
        -1.0f, 0.0f, 0.5f,  1.0f, 1.0f, 1.0f,  0.0f, 1.0f,
        -1.0f, 0.0f, -0.5f, 1.0f, 1.0f, 1.0f,  0.0f, 0.0f,

        1.0f, 0.1f, 0.5f,  1.0f, 1.0f, 1.0f,  1.0f, 1.0f,
        1.0f, 0.1f, -0.5f,  1.0f, 1.0f, 1.0f,  1.0f, 0.0f,
        -1.0f, 0.1f, 0.5f,  1.0f, 1.0f, 1.0f,  0.0f, 1.0f,
        -1.0f, 0.1f, -0.5f,  1.0f, 1.0f, 1.0f,   0.0f, 0.0f,
    };

    
    GLushort indices[] = {

        0, 1, 2,
        1, 2, 3,
        4, 5, 6,
        5, 6, 7,
        0, 4, 2,
        2, 4, 6,
        0, 1, 4,
        1, 4, 5,
        1, 3, 5,
        3, 5, 7,
        2, 3, 7,
        2, 6, 7

    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;


    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);


    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);


    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);


    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}

void UCreateMesh2(GLMesh2& mesh2) {
    GLfloat verts[] = {
        0.0f, 0.0f, 1.0f, 1.0f, 1.0f, 1.0f,   0.0f, 1.0f,
        0.0f, 0.0f, -1.0f, 1.0f, 1.0f, 1.0f,   0.0f, 0.0f,
        2.0f, 0.0f, 1.0f,  1.0f, 1.0f, 1.0f,  1.0f, 1.0f,
        2.0f, 0.0f, -1.0f, 1.0f, 1.0f, 1.0f,  1.0f, 0.0f,
    };


    GLushort indices[] = {
        0, 1, 2,
        1, 2, 3,
    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;


    glGenVertexArrays(1, &mesh2.vao);
    glBindVertexArray(mesh2.vao);


    glGenBuffers(2, mesh2.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh2.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);

    mesh2.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh2.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);


    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);


    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}

void UCreateMesh3(GLMesh3& mesh3) {

    GLfloat verts[] = {
        2.2f, -0.0001f, 2.50f, 1.0f, 1.0f, 1.0f,  1.0f, 1.0f,
        2.2f, -0.0001f, -1.05f, 1.0f, 1.0f, 1.0f,  1.0f, 0.0f,
        -2.5f, -0.0001f, 2.50f, 1.0f, 1.0f, 1.0f,  0.0f, 1.0f,
        -2.5f, -0.0001f, -1.05f,  1.0f, 1.0f, 1.0f,  0.0f, 0.0f
    };


    GLushort indices[] = {

        0, 1, 2,
        1, 2, 3,
    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;


    glGenVertexArrays(1, &mesh3.vao);
    glBindVertexArray(mesh3.vao);


    glGenBuffers(2, mesh3.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh3.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);

    mesh3.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh3.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);


    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);


    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}

void UCreateMesh4(GLMesh4& mesh4) {

    GLfloat verts[] = {

        1.0f, 1.25f, 1.5f,  1.0f, 1.0f, 1.0f,  1.0f, 1.0f,
        1.0f, 0.25f, 1.5f,  1.0f, 1.0f, 1.0f,  1.0f, 0.0f,
        -1.0f, 1.25f, 1.5f,  1.0f, 1.0f, 1.0f,  0.0f, 1.0f,
        -1.0f, 0.25f, 1.5f, 1.0f, 1.0f, 1.0f,  0.0f, 0.0f,

        1.0f, 1.25f, 1.4f,  1.0f, 1.0f, 1.0f,  1.0f, 1.0f,
        1.0f, 0.25f, 1.4f,  1.0f, 1.0f, 1.0f,  1.0f, 0.0f,
        -1.0f, 1.25f, 1.4,  1.0f, 1.0f, 1.0f,  0.0f, 1.0f,
        -1.0f, 0.25f, 1.4f,  1.0f, 1.0f, 1.0f,   0.0f, 0.0f,
    };


    GLushort indices[] = {
        0, 1, 2,
        1, 2, 3,
        4, 5, 6,
        5, 6, 7,
        0, 4, 2,
        2, 4, 6,
        0, 1, 4,
        1, 4, 5,
        1, 3, 5,
        3, 5, 7,
        2, 3, 7,
        2, 6, 7
    };


    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;


    glGenVertexArrays(1, &mesh4.vao);
    glBindVertexArray(mesh4.vao);


    glGenBuffers(2, mesh4.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh4.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);

    mesh4.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh4.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);


    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);


    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}

void UCreateMesh5(GLMesh5& mesh5) {

    GLfloat verts[] = {

        0.0f, 0.0f, 1.45f, 1.0f, 1.0f, 1.0f,  0.5f, 0.5f,
        0.0f, 0.0f, 1.5f, 1.0f, 1.0f, 1.0f,  1.0f, 1.0f,
        0.02f, 0.0f, 1.49f, 1.0f, 1.0f, 1.0f,  1.0f, 1.0f,
        0.03f, 0.0f, 1.48f, 1.0f, 1.0f, 1.0f,  1.0f, 0.5f,
        0.04f, 0.0f, 1.47f, 1.0f, 1.0f, 1.0f,  1.0f, 1.0f,
        0.05f, 0.0f, 1.45f, 1.0f, 1.0f, 1.0f,  1.0f, 0.5f,
        0.0f, 0.0f, 1.40f, 1.0f, 1.0f, 1.0f,  0.5f, 0.0f,
        0.02f, 0.0f, 1.41f, 1.0f, 1.0f, 1.0f,  1.0f, 0.0f,
        0.03f, 0.0f, 1.42f, 1.0f, 1.0f, 1.0f,  1.0f, 0.0f,
        0.04f, 0.0f, 1.43f,  1.0f, 1.0f, 1.0f,  1.0f, 0.0f,
        -0.05f, 0.0f, 1.45f, 1.0f, 1.0f, 1.0f,  0.0f, 0.5f,
        -0.04f, 0.0f, 1.43f, 1.0f, 1.0f, 1.0f,  0.0f, 0.0f,
        -0.03f, 0.0f, 1.42f, 1.0f, 1.0f, 1.0f,  0.0f, 0.0f,
        -0.02f, 0.0f, 1.41f,  1.0f, 1.0f, 1.0f,  0.0f, 0.0f,
        -0.04f, 0.0f, 1.47f, 1.0f, 1.0f, 1.0f,  0.0f, 1.0f,
        -0.03f, 0.0f, 1.48f, 1.0f, 1.0f, 1.0f,  0.0f, 1.0f,
        -0.02f, 0.0f, 1.49f,  1.0f, 1.0f, 1.0f,  0.0f, 1.0f,

        0.0f, 0.25f, 1.45f, 1.0f, 1.0f, 1.0f,  0.5f, 0.5f,
        0.0f, 0.25f, 1.5f, 1.0f, 1.0f, 1.0f,  1.0f, 1.0f,
        0.02f, 0.25f, 1.49f, 1.0f, 1.0f, 1.0f,  1.0f, 1.0f,
        0.03f, 0.25f, 1.48f, 1.0f, 1.0f, 1.0f,  1.0f, 0.5f,
        0.04f, 0.25f, 1.47f, 1.0f, 1.0f, 1.0f,  1.0f, 1.0f,
        0.05f, 0.25f, 1.45f, 1.0f, 1.0f, 1.0f,  1.0f, 0.5f,
        0.0f, 0.25f, 1.40f, 1.0f, 1.0f, 1.0f,  0.5f, 0.0f,
        0.02f, 0.25f, 1.41f, 1.0f, 1.0f, 1.0f,  1.0f, 0.0f,
        0.03f, 0.25f, 1.42f, 1.0f, 1.0f, 1.0f,  1.0f, 0.0f,
        0.04f, 0.25f, 1.43f,  1.0f, 1.0f, 1.0f,  1.0f, 0.0f,
        -0.05f, 0.25f, 1.45f, 1.0f, 1.0f, 1.0f,  0.0f, 0.5f,
        -0.04f, 0.25f, 1.43f, 1.0f, 1.0f, 1.0f,  0.0f, 0.0f,
        -0.03f, 0.25f, 1.42f, 1.0f, 1.0f, 1.0f,  0.0f, 0.0f,
        -0.02f, 0.25f, 1.41f,  1.0f, 1.0f, 1.0f,  0.0f, 0.0f,
        -0.04f, 0.25f, 1.47f, 1.0f, 1.0f, 1.0f,  0.0f, 1.0f,
        -0.03f, 0.25f, 1.48f, 1.0f, 1.0f, 1.0f,  0.0f, 1.0f,
        -0.02f, 0.25f, 1.49f,  1.0f, 1.0f, 1.0f,  0.0f, 1.0f,

        0.0f, 0.0f, 1.45f, 1.0f, 1.0f, 1.0f,  0.5f, 0.5f,
        0.0f, 0.0f, 2.0f, 1.0f, 1.0f, 1.0f,  1.0f, 1.0f,
        0.2f, 0.0f, 1.85f, 1.0f, 1.0f, 1.0f,  1.0f, 1.0f,
        0.3f, 0.0f, 1.75f, 1.0f, 1.0f, 1.0f,  1.0f, 0.5f,
        0.4f, 0.0f, 1.65f, 1.0f, 1.0f, 1.0f,  1.0f, 1.0f,
        0.5f, 0.0f, 1.45f, 1.0f, 1.0f, 1.0f,  1.0f, 0.5f,
        0.0f, 0.0f, 1.0f, 1.0f, 1.0f, 1.0f,  0.5f, 0.0f,
        0.2f, 0.0f, 1.05f, 1.0f, 1.0f, 1.0f,  1.0f, 0.0f,
        0.3f, 0.0f, 1.15f, 1.0f, 1.0f, 1.0f,  1.0f, 0.0f,
        0.4f, 0.0f, 1.25f,  1.0f, 1.0f, 1.0f,  1.0f, 0.0f,
        -0.5f, 0.0f, 1.45f, 1.0f, 1.0f, 1.0f,  0.0f, 0.5f,
        -0.4f, 0.0f, 1.25f, 1.0f, 1.0f, 1.0f,  0.0f, 0.0f,
        -0.3f, 0.0f, 1.15f, 1.0f, 1.0f, 1.0f,  0.0f, 0.0f,
        -0.2f, 0.0f, 1.05f,  1.0f, 1.0f, 1.0f,  0.0f, 0.0f,
        -0.4f, 0.0f, 1.65f, 1.0f, 1.0f, 1.0f,  0.0f, 1.0f,
        -0.3f, 0.0f, 1.75f, 1.0f, 1.0f, 1.0f,  0.0f, 1.0f,
        -0.2f, 0.0f, 1.85f,  1.0f, 1.0f, 1.0f,  0.0f, 1.0f,

        0.0f, 0.1f, 1.45f, 1.0f, 1.0f, 1.0f,  0.5f, 0.5f,
        0.0f, 0.1f, 2.0f, 1.0f, 1.0f, 1.0f,  1.0f, 1.0f,
        0.2f, 0.1f, 1.85f, 1.0f, 1.0f, 1.0f,  1.0f, 1.0f,
        0.3f, 0.1f, 1.75f, 1.0f, 1.0f, 1.0f,  1.0f, 0.5f,
        0.4f, 0.1f, 1.65f, 1.0f, 1.0f, 1.0f,  1.0f, 1.0f,
        0.5f, 0.1f, 1.45f, 1.0f, 1.0f, 1.0f,  1.0f, 0.5f,
        0.0f, 0.1f, 1.0f, 1.0f, 1.0f, 1.0f,  0.5f, 0.0f,
        0.2f, 0.1f, 1.05f, 1.0f, 1.0f, 1.0f,  1.0f, 0.0f,
        0.3f, 0.1f, 1.15f, 1.0f, 1.0f, 1.0f,  1.0f, 0.0f,
        0.4f, 0.1f, 1.25f,  1.0f, 1.0f, 1.0f,  1.0f, 0.0f,
        -0.5f, 0.1f, 1.45f, 1.0f, 1.0f, 1.0f,  0.0f, 0.5f,
        -0.4f, 0.1f, 1.25f, 1.0f, 1.0f, 1.0f,  0.0f, 0.0f,
        -0.3f, 0.1f, 1.15f, 1.0f, 1.0f, 1.0f,  0.0f, 0.0f,
        -0.2f, 0.1f, 1.05f,  1.0f, 1.0f, 1.0f,  0.0f, 0.0f,
        -0.4f, 0.1f, 1.65f, 1.0f, 1.0f, 1.0f,  0.0f, 1.0f,
        -0.3f, 0.1f, 1.75f, 1.0f, 1.0f, 1.0f,  0.0f, 1.0f,
        -0.2f, 0.1f, 1.85f,  1.0f, 1.0f, 1.0f,  0.0f, 1.0f,

    };
    GLushort indices[] = {
        0, 1, 2,
        0, 2, 3,
        0, 3, 4,
        0, 4, 5,
        0, 6, 7,
        0, 7, 8,
        0, 8, 9,
        0, 5, 9,
        0, 10, 11,
        0, 11, 12,
        0, 12, 13,
        0, 6, 13,
        0, 10, 14,
        0, 14, 15,
        0, 15, 16,
        0, 1, 16,

        17, 18, 19,
        17, 19, 20,
        17, 20, 21,
        17, 21, 22,
        17, 23, 24,
        17, 24, 25,
        17, 25, 26,
        17, 22, 26,
        17, 27, 28,
        17, 28, 29,
        17, 29, 30,
        17, 23, 30,
        17, 27, 31,
        17, 31, 32,
        17, 32, 33,
        17, 18, 33,

        34, 35, 36,
        34, 36, 37,
        34, 37, 38,
        34, 38, 39,
        34, 40, 41,
        34, 41, 42,
        34, 42, 43,
        34, 39, 43,
        34, 44, 45,
        34, 45, 46,
        34, 46, 47,
        34, 40, 47,
        34, 44, 48,
        34, 48, 49,
        34, 49, 50,
        34, 44, 48,
        34, 35, 50,

        51, 52, 53,
        51, 53, 54,
        51, 54, 55,
        51, 55, 56,
        51, 57, 58,
        51, 58, 59,
        51, 59, 60,
        51, 56, 60,
        51, 61, 62,
        51, 62, 63,
        51, 63, 64,
        51, 57, 64,
        51, 61, 65,
        51, 65, 66,
        51, 66, 67,
        51, 67, 52,


        1, 2, 18,
        2, 18, 19,
        2, 3, 19,
        3, 19, 20,
        3, 4, 20,
        4, 20, 21,
        4, 5, 21,
        5, 21, 22,
        5, 9, 22,
        9, 22, 26,
        8, 9, 26,
        8, 26, 25,
        7, 8, 25,
        7, 24, 25,
        6, 7, 24,
        6, 23, 24,
        6, 13, 23,
        13, 23, 30,
        12, 13, 30,
        12, 29, 30,
        11, 12, 29,
        11, 28, 29,
        10, 11, 28,
        10, 27, 28,
        10, 14, 27,
        14, 27, 31,
        14, 15, 31,
        15, 31, 32,
        15, 16, 32,
        16, 32, 33,
        1, 16, 33,
        1, 18, 33,

        35, 36, 52,
        36, 52, 53,
        36, 37, 53,
        37, 53, 54,
        37, 38, 54,
        38, 54, 55,
        38, 39, 55,
        39, 55, 56,
        39, 43, 56,
        43, 56, 60,
        42, 43, 60,
        42, 59, 60,
        41, 42, 59,
        41, 58, 59,
        40, 41, 58,
        40, 57, 58,
        40, 47, 57,
        47, 57, 64,
        46, 47, 64,
        46, 63, 64,
        45, 46, 63,
        45, 62, 63,
        44, 45, 62,
        44, 61, 62,
        44, 48, 61,
        48, 61, 65,
        48, 49, 65,
        49, 65, 66,
        49, 50, 66,
        50, 66, 67,
        35, 50, 67,
        35, 52, 67,
    };


    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;


    glGenVertexArrays(1, &mesh5.vao);
    glBindVertexArray(mesh5.vao);


    glGenBuffers(2, mesh5.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh5.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);

    mesh5.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh5.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);


    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);


    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}





void UDestroyMesh(GLMesh& mesh) {
    glDeleteVertexArrays(1, &mesh.vao);
    glDeleteBuffers(2, mesh.vbos);
}
void UDestroyMesh2(GLMesh2& mesh2) {
    glDeleteVertexArrays(1, &mesh2.vao);
    glDeleteBuffers(2, mesh2.vbos);
}
void UDestroyMesh3(GLMesh3& mesh3) {
    glDeleteVertexArrays(1, &mesh3.vao);
    glDeleteBuffers(2, mesh3.vbos);
}
void UDestroyMesh4(GLMesh4& mesh4) {
    glDeleteVertexArrays(1, &mesh4.vao);
    glDeleteBuffers(2, mesh4.vbos);
}
void UDestroyMesh5(GLMesh5& mesh5) {
    glDeleteVertexArrays(1, &mesh5.vao);
    glDeleteBuffers(2, mesh5.vbos);
}

bool UCreateTexture(const char* filename, GLuint& textureId)
{   
    
    int width, height, channels;
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);


        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);



        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (channels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0);




        return true;
    }


    return false;
}



void UDestroyTexture(GLuint textureId)
{
    glGenTextures(1, &textureId);
}





bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId) {

    int success = 0;
    char infoLog[512];


    programId = glCreateProgram();


    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);


    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);


    glCompileShader(vertexShaderId);

    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success) {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glCompileShader(fragmentShaderId);
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success) {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }


    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success) {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glUseProgram(programId);

    return true;
}


void UDestroyShaderProgram(GLuint programId) {
    glDeleteProgram(programId);
}
